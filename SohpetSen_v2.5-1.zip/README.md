# SohpetSen v2.5

SohpetSen'in yayın öncesi güvenlik ve ses altyapısı hazırlık paketi.

## Bu sürüm
- JWT için güvenli üretim davranışı
- Rate-limit belleğinin periyodik temizlenmesi
- WebRTC signaling mesajlarının aynı odadaki socket'lere sınırlandırılması
- Android sürümü 2.5.0
- Backend sürümü 2.5.0
- Üretim ortamı için `.env.example`

## Önemli
Bu kaynak paket tek başına Google Play'e yüklenmiş çalışan bir kamu servisi değildir. Yayından önce HTTPS/WSS, gerçek TURN + SFU, üretim veritabanı/yedekleme, alan adı, gizlilik politikası, kullanım şartları ve Play Console beyanları tamamlanmalıdır.

P2P mesh ses sistemi küçük odalar için prototip seviyesindedir. Büyük odalarda SFU kullanılmalıdır.


## v2.2
- `/api/ready` üretim öncesi hazır olma kontrolleri.
- Sağlık sürümü 2.2.0.

## v2.5
- Android oturumunun cihazda güvenli SharedPreferences ile korunması.
- Çıkışta yerel oturumun temizlenmesi.

## v2.4
- Helmet güvenlik başlıkları
- Üretimde zorunlu CORS_ORIGIN
- Giriş/kayıt için ayrı brute-force rate limit
- Android sürüm 2.4.0
