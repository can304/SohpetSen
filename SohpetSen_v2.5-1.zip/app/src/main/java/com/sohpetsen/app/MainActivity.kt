package com.sohpetsen.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.google.gson.annotations.SerializedName
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import org.json.JSONObject

private const val SERVER = BuildConfig.API_BASE_URL
private val Purple = Color(0xFF6C35FF)
private val Bg = Color(0xFFF7F7F8)
private val Dark = Color(0xFF17131F)

data class User(val id:String,val username:String,val role:String)
data class AuthResponse(val token:String,val user:User)
data class Room(val id:String,val name:String,@SerializedName("ownerId") val ownerId:String,val createdAt:String,val messageCount:Int=0)
data class Chat(val id:String,val userId:String,val username:String,val text:String,val at:String)
data class LoginBody(val username:String,val password:String)
data class RegisterBody(val username:String,val password:String)
data class CreateRoomBody(val name:String)
data class MessageBody(val text:String)
data class Member(val userId:String,val username:String,val role:String,val joinedAt:String)
data class UserSearch(val id:String,val username:String,val role:String,val createdAt:String)
data class Conversation(val userId:String,val username:String,val text:String,val at:String)
data class DirectMessage(val id:String,val senderId:String,val receiverId:String,val text:String,val at:String,val readAt:String?=null)
data class Wallet(val userId:String,val coins:Int,val level:Int,val xp:Int)
data class Gift(val id:String,val name:String,val cost:Int,val icon:String)
data class Notice(val id:String,val type:String,val title:String,val body:String,val readAt:String?,val createdAt:String)
data class Leader(val id:String,val username:String,val level:Int,val xp:Int)

interface Api {
 @POST("api/register") suspend fun register(@Body b:RegisterBody):AuthResponse
 @POST("api/login") suspend fun login(@Body b:LoginBody):AuthResponse
 @GET("api/rooms") suspend fun rooms():List<Room>
 @POST("api/rooms") suspend fun createRoom(@Header("Authorization") token:String,@Body b:CreateRoomBody):Room
 @GET("api/rooms/{id}/messages") suspend fun messages(@Path("id") id:String):List<Chat>
 @GET("api/rooms/{id}/members") suspend fun members(@Header("Authorization") token:String,@Path("id") id:String):List<Member>
 @POST("api/rooms/{id}/join") suspend fun join(@Header("Authorization") token:String,@Path("id") id:String):Map<String,Any>
 @POST("api/rooms/{id}/request-speaker") suspend fun requestSpeaker(@Header("Authorization") token:String,@Path("id") id:String):Map<String,Any>
 @POST("api/rooms/{id}/leave") suspend fun leave(@Header("Authorization") token:String,@Path("id") id:String):Map<String,Any>
 @PATCH("api/rooms/{id}/members/{userId}/role") suspend fun setRole(@Header("Authorization") token:String,@Path("id") id:String,@Path("userId") userId:String,@Body body:Map<String,String>):Map<String,Any>
 @POST("api/rooms/{id}/messages") suspend fun send(@Header("Authorization") token:String,@Path("id") id:String,@Body b:MessageBody):Chat
 @GET("api/users/search") suspend fun searchUsers(@Header("Authorization") token:String,@Query("q") q:String):List<UserSearch>
 @GET("api/messages/conversations") suspend fun conversations(@Header("Authorization") token:String):List<Conversation>
 @GET("api/messages/{userId}") suspend fun directMessages(@Header("Authorization") token:String,@Path("userId") userId:String):List<DirectMessage>
 @POST("api/messages/{userId}") suspend fun sendDirect(@Header("Authorization") token:String,@Path("userId") userId:String,@Body b:MessageBody):DirectMessage
 @POST("api/users/{id}/follow") suspend fun follow(@Header("Authorization") token:String,@Path("id") id:String):Map<String,Any>
 @DELETE("api/users/{id}/follow") suspend fun unfollow(@Header("Authorization") token:String,@Path("id") id:String):Map<String,Any>
 @GET("api/admin/users") suspend fun adminUsers(@Header("Authorization") token:String):List<UserSearch>
 @PATCH("api/admin/users/{id}/role") suspend fun adminRole(@Header("Authorization") token:String,@Path("id") id:String,@Body body:Map<String,String>):Map<String,Any>
 @GET("api/wallet") suspend fun wallet(@Header("Authorization") token:String):Wallet
 @GET("api/gifts") suspend fun gifts(@Header("Authorization") token:String):List<Gift>
 @POST("api/gifts/send") suspend fun sendGift(@Header("Authorization") token:String,@Body body:Map<String,String?>):Map<String,Any>
 @GET("api/notifications") suspend fun notifications(@Header("Authorization") token:String):List<Notice>
 @POST("api/notifications/read") suspend fun readNotifications(@Header("Authorization") token:String):Map<String,Any>
 @GET("api/leaderboard") suspend fun leaderboard(@Header("Authorization") token:String):List<Leader>
 @DELETE("api/me") suspend fun deleteAccount(@Header("Authorization") token:String):Map<String,Any>
}

object Backend {
 private val http=OkHttpClient.Builder().addInterceptor(HttpLoggingInterceptor().apply{level=HttpLoggingInterceptor.Level.BASIC}).build()
 val api:Api=Retrofit.Builder().baseUrl(SERVER).client(http).addConverterFactory(GsonConverterFactory.create()).build().create(Api::class.java)
}

object SessionStore {
    private const val PREFS = "sohpetsen_session"
    private const val TOKEN = "token"
    private const val USER_ID = "user_id"
    private const val USERNAME = "username"
    private const val ROLE = "role"
    fun save(context: Context, auth: AuthResponse) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(TOKEN, auth.token).putString(USER_ID, auth.user.id)
            .putString(USERNAME, auth.user.username).putString(ROLE, auth.user.role).apply()
    }
    fun load(context: Context): AuthResponse? {
        val p=context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val token=p.getString(TOKEN,null) ?: return null
        val id=p.getString(USER_ID,null) ?: return null
        val username=p.getString(USERNAME,null) ?: return null
        return AuthResponse(token, User(id, username, p.getString(ROLE,"user") ?: "user"))
    }
    fun clear(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply() }
}

class MainActivity:ComponentActivity(){
 private val micPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{SohpetSenApp({if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)micPermission.launch(Manifest.permission.RECORD_AUDIO)})}}
}

@Composable fun SohpetSenApp(requestMic:()->Unit){
 val context=LocalContext.current
 var auth by remember{mutableStateOf(SessionStore.load(context))}
 if(auth==null) LoginScreen{SessionStore.save(context,it);auth=it}else MainApp(auth!!,requestMic){SessionStore.clear(context);auth=null}
}

@Composable fun LoginScreen(onAuth:(AuthResponse)->Unit){
 val scope=rememberCoroutineScope();var register by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)}
 Column(Modifier.fillMaxSize().background(Bg).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){Spacer(Modifier.height(60.dp));Box(Modifier.size(92.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text("S",color=Color.White,fontSize=50.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(14.dp));Text("SohpetSen",fontSize=34.sp,fontWeight=FontWeight.Bold,color=Purple);Text(if(register)"Yeni hesap oluştur" else "Sesli sohbetin yeni adresi",color=Color.Gray);Spacer(Modifier.height(34.dp));OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("Kullanıcı adı")},singleLine=true);Spacer(Modifier.height(10.dp));OutlinedTextField(pass,{pass=it},Modifier.fillMaxWidth(),label={Text("Şifre")},singleLine=true);Spacer(Modifier.height(14.dp));Button(enabled=!busy,onClick={scope.launch{busy=true;error="";try{val r=withContext(Dispatchers.IO){if(register)Backend.api.register(RegisterBody(name.trim(),pass)) else Backend.api.login(LoginBody(name.trim(),pass))};onAuth(r)}catch(e:Exception){error=e.message?:"Bağlantı hatası"};busy=false}},Modifier.fillMaxWidth().height(52.dp),shape=RoundedCornerShape(16.dp)){Text(if(register)"Kayıt Ol" else "Giriş Yap")};Spacer(Modifier.height(12.dp));TextButton{register=!register}{Text(if(register)"Zaten hesabım var" else "Yeni hesap oluştur")};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,fontSize=13.sp)}
}

@Composable fun MainApp(auth:AuthResponse,requestMic:()->Unit,onLogout:()->Unit){
 var tab by remember{mutableStateOf(0)};var selected by remember{mutableStateOf<Room?>(null)};var admin by remember{mutableStateOf(false)};var rooms by remember{mutableStateOf<List<Room>>(emptyList())};var refresh by remember{mutableStateOf(0)};val scope=rememberCoroutineScope()
 LaunchedEffect(refresh){try{rooms=withContext(Dispatchers.IO){Backend.api.rooms()}}catch(_:Exception){}}
 if(selected!=null){RoomScreen(auth,selected!!,requestMic){selected=null};return};if(admin){AdminScreen(auth){admin=false};return}
 Scaffold(bottomBar={NavigationBar{listOf("🎙" to "Odalar","💬" to "Mesajlar","👤" to "Profil").forEachIndexed{i,p->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Text(p.first,fontSize=20.sp)},label={Text(p.second)})}}}){pad->when(tab){0->HomeScreen(Modifier.padding(pad),rooms,{selected=it},{name->scope.launch{try{withContext(Dispatchers.IO){Backend.api.createRoom("Bearer ${auth.token}",CreateRoomBody(name))};refresh++}catch(_:Exception){}}});1->MessagesScreen(Modifier.padding(pad),auth);else->ProfileScreen(Modifier.padding(pad),auth,onLogout){if(auth.user.role=="admin")admin=true}}}}
}

@Composable fun HomeScreen(mod:Modifier,rooms:List<Room>,open:(Room)->Unit,create:(String)->Unit){var show by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};Column(mod.fillMaxSize().background(Bg).padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("SohpetSen",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Purple);Text("Canlı odaları keşfet",color=Color.Gray)};Text("🔔",fontSize=25.sp)};Spacer(Modifier.height(16.dp));Button(onClick={show=true},Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Text("＋ Yeni Oda Oluştur")};if(show){Spacer(Modifier.height(8.dp));OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("Oda adı")});Button(onClick={if(name.isNotBlank()){create(name.trim());name="";show=false}},Modifier.fillMaxWidth()){Text("Odayı oluştur")}};Spacer(Modifier.height(18.dp));Text("Canlı Odalar",fontSize=22.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));if(rooms.isEmpty())Text("Henüz oda yok. İlk odayı sen oluştur!",color=Color.Gray) else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(rooms){r->Card(Modifier.fillMaxWidth().clickable{open(r)},shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(50.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text("🎙",fontSize=23.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(r.name,fontWeight=FontWeight.Bold,fontSize=18.sp);Text("Oda",color=Color.Gray)};Text("💬 ${r.messageCount}")}}}}}}

@Composable fun RoomScreen(auth:AuthResponse,room:Room,requestMic:()->Unit,onBack:()->Unit){
 var mic by remember{mutableStateOf(false)};var chat by remember{mutableStateOf<List<Chat>>(emptyList())};var members by remember{mutableStateOf<List<Member>>(emptyList())};var msg by remember{mutableStateOf("")};var status by remember{mutableStateOf("")};var socket by remember{mutableStateOf<Socket?>(null)};var voice by remember{mutableStateOf<VoiceRoomManager?>(null)};val scope=rememberCoroutineScope();val context=LocalContext.current
 LaunchedEffect(room.id){
  try{withContext(Dispatchers.IO){Backend.api.join("Bearer ${auth.token}",room.id);members=Backend.api.members("Bearer ${auth.token}",room.id);chat=Backend.api.messages(room.id)}}catch(_:Exception){}
  try{val s=IO.socket(SERVER,IO.Options().apply{auth=mapOf("token" to auth.token)});s.on("member:changed"){scope.launch{try{members=withContext(Dispatchers.IO){Backend.api.members("Bearer ${auth.token}",room.id)}}catch(_:Exception){}}};s.on("message"){args->val o=args[0] as JSONObject;val c=Chat(o.getString("id"),o.getString("userId"),o.getString("username"),o.getString("text"),o.getString("at"));scope.launch{chat=chat+c}};voice=VoiceRoomManager(context,s);socket=s;s.connect();s.emit("joinRoom",room.id)}catch(e:Exception){status=e.message?:"Ses bağlantısı kurulamadı."}
 }
 DisposableEffect(room.id){onDispose{voice?.close();socket?.emit("leaveRoom");socket?.disconnect();scope.launch{try{withContext(Dispatchers.IO){Backend.api.leave("Bearer ${auth.token}",room.id)}}catch(_:Exception){}}}}
 Column(Modifier.fillMaxSize().background(Dark)){
  Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",color=Color.White,fontSize=36.sp,modifier=Modifier.clickable{onBack()});Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(room.name,color=Color.White,fontWeight=FontWeight.Bold,fontSize=20.sp);Text("Canlı ses odası • ${members.size} kişi",color=Color.LightGray)};Text("🟢",fontSize=16.sp)}
  if(status.isNotBlank())Text(status,color=Color(0xFFB8A8FF),modifier=Modifier.padding(horizontal=16.dp,vertical=4.dp))
  Text("🎤 Oda üyeleri",color=Color.White,fontSize=18.sp,modifier=Modifier.padding(16.dp,top=8.dp,bottom=8.dp))
  LazyColumn(Modifier.heightIn(max=220.dp).padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(members){m->Row(Modifier.fillMaxWidth().background(Color(0xFF241D2E),RoundedCornerShape(14.dp)).padding(10.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(42.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text("👤")};Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(m.username,color=Color.White,fontWeight=FontWeight.Bold);Text(m.role,color=Color.LightGray,fontSize=12.sp)};if(m.role=="speaker")Text("🎙️",fontSize=20.sp) else if(m.role=="moderator"||m.role=="owner")Text("⭐",fontSize=18.sp)}}}
  Spacer(Modifier.height(8.dp));Text("Oda sohbeti",color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp,modifier=Modifier.padding(horizontal=16.dp));LazyColumn(Modifier.weight(1f).padding(horizontal=16.dp)){items(chat){c->Text("${c.username}: ${c.text}",color=Color.White,modifier=Modifier.padding(vertical=5.dp))}}
  Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){OutlinedTextField(msg,{msg=it},Modifier.weight(1f),placeholder={Text("Mesaj yaz…")});Spacer(Modifier.width(6.dp));Button(onClick={val t=msg.trim();if(t.isNotEmpty()){scope.launch{try{withContext(Dispatchers.IO){Backend.api.send("Bearer ${auth.token}",room.id,MessageBody(t))};msg=""}catch(_:Exception){}}}}){Text("Gönder")}}
  Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){FilledTonalButton(onClick={requestMic();if(ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){mic=!mic;voice?.setMicrophoneEnabled(mic)}else{status="Mikrofon izni gerekiyor."}}){Text(if(mic)"🎙 Mikrofon açık" else "🔇 Mikrofon kapalı")};OutlinedButton(onClick={scope.launch{try{withContext(Dispatchers.IO){Backend.api.requestSpeaker("Bearer ${auth.token}",room.id)};status="Konuşmacı isteğin gönderildi."}catch(e:Exception){status=e.message?:"İstek gönderilemedi."}}}){Text("🙋 Konuşmak istiyorum")};Button(onClick=onBack){Text("Çıkış")}}
 }
}

@Composable fun MessagesScreen(mod:Modifier,auth:AuthResponse){var query by remember{mutableStateOf("")};var users by remember{mutableStateOf<List<UserSearch>>(emptyList())};var conversations by remember{mutableStateOf<List<Conversation>>(emptyList())};var selected by remember{mutableStateOf<UserSearch?>(null)};val scope=rememberCoroutineScope()
 LaunchedEffect(Unit){try{conversations=withContext(Dispatchers.IO){Backend.api.conversations("Bearer ${auth.token}")}}catch(_:Exception){}}
 if(selected!=null){DirectChatScreen(auth,selected!!){selected=null};return}
 Column(mod.fillMaxSize().padding(20.dp)){Text("Mesajlar",fontSize=28.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("Kullanıcı ara")},singleLine=true);if(query.length>=2){LaunchedEffect(query){try{users=withContext(Dispatchers.IO){Backend.api.searchUsers("Bearer ${auth.token}",query)}}catch(_:Exception){}};LazyColumn{items(users){u->Row(Modifier.fillMaxWidth().clickable{selected=u}.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(44.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text("👤")};Spacer(Modifier.width(10.dp));Column{Text(u.username,fontWeight=FontWeight.Bold);Text(u.role,color=Color.Gray,fontSize=12.sp)}}}}}else{Spacer(Modifier.height(18.dp));Text("Son konuşmalar",fontWeight=FontWeight.Bold,fontSize=18.sp);LazyColumn{items(conversations){c->Row(Modifier.fillMaxWidth().clickable{selected=UserSearch(c.userId,c.username,"user","")}.padding(14.dp)){Column{Text(c.username,fontWeight=FontWeight.Bold);Text(c.text,color=Color.Gray)}}}}}}}

@Composable fun DirectChatScreen(auth:AuthResponse,user:UserSearch,onBack:()->Unit){var messages by remember{mutableStateOf<List<DirectMessage>>(emptyList())};var text by remember{mutableStateOf("")};val scope=rememberCoroutineScope();LaunchedEffect(user.id){try{messages=withContext(Dispatchers.IO){Backend.api.directMessages("Bearer ${auth.token}",user.id)}}catch(_:Exception){}}
 Column(Modifier.fillMaxSize().background(Bg)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=36.sp,modifier=Modifier.clickable{onBack()});Spacer(Modifier.width(12.dp));Text(user.username,fontWeight=FontWeight.Bold,fontSize=20.sp)};LazyColumn(Modifier.weight(1f).padding(16.dp)){items(messages){m->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.senderId==auth.user.id)Arrangement.End else Arrangement.Start){Text(m.text,Modifier.padding(5.dp).background(if(m.senderId==auth.user.id)Purple else Color.White,RoundedCornerShape(14.dp)).padding(10.dp),color=if(m.senderId==auth.user.id)Color.White else Color.Black)}}};Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){OutlinedTextField(text,{text=it},Modifier.weight(1f),placeholder={Text("Mesaj yaz…")});Spacer(Modifier.width(6.dp));Button(onClick={val t=text.trim();if(t.isNotEmpty()){scope.launch{try{val m=withContext(Dispatchers.IO){Backend.api.sendDirect("Bearer ${auth.token}",user.id,MessageBody(t))};messages=messages+m;text=""}catch(_:Exception){}}}}){Text("Gönder")}}}
}

@Composable fun AdminScreen(auth:AuthResponse,onBack:()->Unit){var users by remember{mutableStateOf<List<UserSearch>>(emptyList())};val scope=rememberCoroutineScope();LaunchedEffect(Unit){try{users=withContext(Dispatchers.IO){Backend.api.adminUsers("Bearer ${auth.token}")}}catch(_:Exception){}};Column(Modifier.fillMaxSize().padding(20.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=36.sp,modifier=Modifier.clickable{onBack()});Spacer(Modifier.width(10.dp));Text("Yönetim Paneli",fontSize=26.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(14.dp));Text("Kullanıcılar: ${users.size}",fontWeight=FontWeight.Bold);LazyColumn{items(users){u->Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(u.username,fontWeight=FontWeight.Bold);Text(u.role,color=Color.Gray)};if(u.id!=auth.user.id){TextButton(onClick={scope.launch{try{withContext(Dispatchers.IO){Backend.api.adminRole("Bearer ${auth.token}",u.id,mapOf("role" to "moderator"))};users=withContext(Dispatchers.IO){Backend.api.adminUsers("Bearer ${auth.token}")}}catch(_:Exception){}}}){Text("Moderatör")}}}}}}}
}

@Composable fun ProfileScreen(mod:Modifier,auth:AuthResponse,onLogout:()->Unit,onAdmin:()->Unit){
 var wallet by remember{mutableStateOf<Wallet?>(null)};var notices by remember{mutableStateOf<List<Notice>>(emptyList())};var leaders by remember{mutableStateOf<List<Leader>>(emptyList())};var gifts by remember{mutableStateOf<List<Gift>>(emptyList())};var showGifts by remember{mutableStateOf(false)};var showLeaders by remember{mutableStateOf(false)};var showNotices by remember{mutableStateOf(false)};val scope=rememberCoroutineScope()
 LaunchedEffect(Unit){try{wallet=withContext(Dispatchers.IO){Backend.api.wallet("Bearer ${auth.token}")};gifts=withContext(Dispatchers.IO){Backend.api.gifts("Bearer ${auth.token}")};notices=withContext(Dispatchers.IO){Backend.api.notifications("Bearer ${auth.token}")};leaders=withContext(Dispatchers.IO){Backend.api.leaderboard("Bearer ${auth.token}")}}catch(_:Exception){}}
 if(showGifts){GiftScreen(auth,gifts){showGifts=false};return};if(showLeaders){LeaderboardScreen(leaders){showLeaders=false};return};if(showNotices){NotificationScreen(auth,notices){showNotices=false};return}
 Column(mod.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Spacer(Modifier.height(20.dp));Box(Modifier.size(100.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text("👤",fontSize=44.sp)};Spacer(Modifier.height(12.dp));Text(auth.user.username,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("@${auth.user.username}",color=Color.Gray);Spacer(Modifier.height(18.dp));
 Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Seviye ${wallet?.level?:1}",fontWeight=FontWeight.Bold,fontSize=19.sp);Text("${wallet?.xp?:0} XP",color=Color.Gray)};Text("🪙 ${wallet?.coins?:0}",fontWeight=FontWeight.Bold,fontSize=18.sp)}}
 Spacer(Modifier.height(14.dp));Button(onClick={showGifts=true},Modifier.fillMaxWidth()){Text("🎁 Hediyeler")};Spacer(Modifier.height(8.dp));OutlinedButton(onClick={showLeaders=true},Modifier.fillMaxWidth()){Text("🏆 Liderlik Tablosu")};Spacer(Modifier.height(8.dp));OutlinedButton(onClick={showNotices=true},Modifier.fillMaxWidth()){Text("🔔 Bildirimler${if(notices.any{it.readAt==null})" • Yeni" else ""}")};if(auth.user.role=="admin"){Spacer(Modifier.height(8.dp));OutlinedButton(onClick=onAdmin,Modifier.fillMaxWidth()){Text("⚙ Yönetim Paneli")}};Spacer(Modifier.height(12.dp));Text("Rol: ${auth.user.role}",color=Color.Gray);Spacer(Modifier.height(12.dp));var confirmDelete by remember{mutableStateOf(false)};OutlinedButton(onClick={confirmDelete=true},Modifier.fillMaxWidth()){Text("Hesabımı Sil")};if(confirmDelete){AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Hesabı sil?")},text={Text("Hesabın ve uygulamadaki kişisel verilerin silinecek. Bu işlem geri alınamaz.")},confirmButton={TextButton(onClick={scope.launch{try{withContext(Dispatchers.IO){Backend.api.deleteAccount("Bearer ${auth.token}")};onLogout()}catch(_:Exception){}finally{confirmDelete=false}}}){Text("Sil")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("İptal")}})};Spacer(Modifier.height(8.dp));OutlinedButton(onClick=onLogout,Modifier.fillMaxWidth()){Text("Çıkış Yap")}}
}

@Composable fun GiftScreen(auth:AuthResponse,gifts:List<Gift>,onBack:()->Unit){var receiver by remember{mutableStateOf("")};var message by remember{mutableStateOf("")};val scope=rememberCoroutineScope();Column(Modifier.fillMaxSize().padding(20.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=36.sp,modifier=Modifier.clickable{onBack()});Spacer(Modifier.width(10.dp));Text("Hediyeler",fontSize=26.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(10.dp));OutlinedTextField(receiver,{receiver=it},Modifier.fillMaxWidth(),label={Text("Alıcı kullanıcı ID")});Text(message,color=Color.Gray);Spacer(Modifier.height(10.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(gifts){g->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(g.icon,fontSize=28.sp);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(g.name,fontWeight=FontWeight.Bold);Text("${g.cost} coin",color=Color.Gray)};Button(enabled=receiver.isNotBlank(),onClick={scope.launch{try{withContext(Dispatchers.IO){Backend.api.sendGift("Bearer ${auth.token}",mapOf("receiverId" to receiver,"giftId" to g.id,"roomId" to null))};message="Hediye gönderildi."}catch(e:Exception){message=e.message?:"Hata"}}}){Text("Gönder")}}}}}}}

@Composable fun LeaderboardScreen(leaders:List<Leader>,onBack:()->Unit){Column(Modifier.fillMaxSize().padding(20.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=36.sp,modifier=Modifier.clickable{onBack()});Spacer(Modifier.width(10.dp));Text("Liderlik Tablosu",fontSize=26.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(leaders){l->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text("#${leaders.indexOf(l)+1}",fontWeight=FontWeight.Bold,modifier=Modifier.width(42.dp));Column(Modifier.weight(1f)){Text(l.username,fontWeight=FontWeight.Bold);Text("Seviye ${l.level} • ${l.xp} XP",color=Color.Gray)}}}}}}}

@Composable fun NotificationScreen(auth:AuthResponse,notices:List<Notice>,onBack:()->Unit){val scope=rememberCoroutineScope();Column(Modifier.fillMaxSize().padding(20.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=36.sp,modifier=Modifier.clickable{onBack()});Spacer(Modifier.width(10.dp));Text("Bildirimler",fontSize=26.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(10.dp));Button(onClick={scope.launch{try{withContext(Dispatchers.IO){Backend.api.readNotifications("Bearer ${auth.token}")}}catch(_:Exception){}}},Modifier.fillMaxWidth()){Text("Tümünü okundu işaretle")};Spacer(Modifier.height(8.dp));if(notices.isEmpty())Text("Henüz bildirim yok.",color=Color.Gray) else LazyColumn{items(notices){n->Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Column(Modifier.padding(14.dp)){Text(n.title,fontWeight=FontWeight.Bold);Text(n.body);Text(n.createdAt,color=Color.Gray,fontSize=11.sp)}}}}}}
